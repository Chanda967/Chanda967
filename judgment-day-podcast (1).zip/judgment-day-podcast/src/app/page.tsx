
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { Play } from "lucide-react";

export default function PodcastWebsite() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch("https://formspree.io/f/xdoqvdrp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    if (res.ok) {
      setStatus("Message sent!");
      setForm({ name: "", email: "", message: "" });
    } else {
      setStatus("Something went wrong.");
    }
  };

  return (
    <div className="bg-black text-white min-h-screen p-6 font-sans">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold">Judgment Day</h1>
        <p className="text-lg mt-4 max-w-2xl mx-auto">
          In a world full of chaos, crime, and conflict, how does the law respond? "Judgment Day" explores real-life cases and the justice — or lack thereof — that followed. From the bizarre to the heartbreaking, we dive into how legal systems around the world have handled humanity's most complex moments.
        </p>
      </header>

      <section className="max-w-4xl mx-auto py-10">
        <h2 className="text-2xl font-semibold mb-4">Meet the Host</h2>
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6">
            <p>
              I'm the voice behind "Judgment Day" — a passionate storyteller with a background in law and a fascination for the real stories behind legal headlines. My mission is to make legal cases not only accessible, but unforgettable.
            </p>
          </CardContent>
        </Card>
      </section>

      <section className="max-w-4xl mx-auto py-10">
        <h2 className="text-2xl font-semibold mb-4">Listen Now</h2>
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6 flex items-center space-x-4">
            <Button className="rounded-full p-4 bg-purple-600">
              <Play className="w-6 h-6" />
            </Button>
            <div>
              <p className="font-medium">Trailer: What is Judgment Day?</p>
              <p className="text-sm text-gray-400">Coming Soon</p>
            </div>
          </CardContent>
        </Card>
        <div className="mt-6 text-center">
          <a href="https://open.spotify.com" target="_blank" rel="noopener noreferrer" className="text-purple-400 underline">
            Listen on Spotify
          </a>
        </div>
      </section>

      <section className="max-w-4xl mx-auto py-10">
        <h2 className="text-2xl font-semibold mb-4">Blog</h2>
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6">
            <h3 className="font-semibold text-xl mb-2">Why Law Needs Storytellers</h3>
            <p className="text-gray-300 mb-2">
              Laws are written, but stories are lived. In this blog, I’ll unpack fascinating case studies, reveal hidden legal truths, and highlight the moments where justice either triumphed — or failed.
            </p>
            <p className="text-sm text-purple-400">More posts coming soon...</p>
          </CardContent>
        </Card>
      </section>

      <section className="max-w-4xl mx-auto py-10">
        <h2 className="text-2xl font-semibold mb-4">Contact Me</h2>
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6 space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input name="name" value={form.name} onChange={handleChange} placeholder="Your Name" className="bg-gray-800 text-white" required />
              <Input name="email" type="email" value={form.email} onChange={handleChange} placeholder="Your Email" className="bg-gray-800 text-white" required />
              <Textarea name="message" value={form.message} onChange={handleChange} placeholder="Your Message" className="bg-gray-800 text-white" rows={4} required />
              <Button type="submit" className="bg-purple-600 w-full">Send Message</Button>
              {status && <p className="text-sm text-gray-400 mt-2">{status}</p>}
            </form>
          </CardContent>
        </Card>
      </section>

      <footer className="text-center py-10 text-gray-500">
        &copy; {new Date().getFullYear()} Judgment Day Podcast. All rights reserved.
      </footer>
    </div>
  );
}
